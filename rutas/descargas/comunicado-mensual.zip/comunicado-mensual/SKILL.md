---
name: comunicado-mensual
description: Prepara el comunicado mensual de una junta de vecinos a partir de gastos, cuotas y acuerdos. Úsalo cuando pidan el comunicado, el resumen o el informe del mes.
---

# Comunicado mensual

## Qué entregas
1. Tabla de gastos pagados con el total.
2. Tres cifras: recaudado, balance del mes (recaudado menos gastos pagados) y monto por cobrar.
3. Mensaje para WhatsApp de máximo 120 palabras, en tono cordial y directo.
4. Lista de pendientes.

## Reglas
- Usa solo las fuentes que te den. Si falta un dato, dilo y no lo completes.
- Un gasto cuenta como pagado solo si la fuente lo dice. Una cotización va en pendientes.
- Nunca nombres apartamentos ni personas con cuotas pendientes. Da solo cantidad y monto.
- Lo pendiente o por confirmar se presenta como pendiente, nunca como decidido.

## Antes de entregar
- Muestra cada suma con sus sumandos.
- Lista qué asumiste y qué no pudiste comprobar.
- Si los números no cuadran, dilo antes del mensaje.
